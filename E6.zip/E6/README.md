# KidsLink 

## Projeto para Análise de Sistemas 

Departamento de Electrónica, Telecomunicações e Informática - Universidade de Aveiro

[https://github.com/GuilhermeCasal/ASProject](https://github.com/GuilhermeCasal/ASProject)


## Instruções

Para experimentar a aplicação simplesmente precisa de abrir o ficheiro index.html e criar um login


---
## Equipa

| Nome 			    |     Contribuição(%)   |

| Inês Moreira 		|  	        20	 	    |
| Gabriel Couto		|  	        20		    |
| Bernardo Marçal 	|  	        20		    |
| Guilherme Martins |  	        20		    |
| Ricardo Machado 	|  	        20		    |

